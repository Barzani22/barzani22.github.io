<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to the Barzani Website</title>

  <style>
    body {
      font-family: Tahoma, sans-serif;
      background-color: #f4f4f9;
      margin: 0;
      padding: 0;
      text-align: center;
    }

    header {
      background-color: #4a90e2;
      color: white;
      padding: 50px 20px;
    }

    header img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      border: 3px solid white;
      margin-bottom: 20px;
      object-fit: cover;
    }

    header h1 {
      margin: 10px 0;
    }

    header p {
      font-size: 18px;
      margin: 5px 0;
    }

    .social a {
      text-decoration: none;
      color: #fff;
      margin: 0 10px;
      font-weight: bold;
      display: inline-block;
    }

    section {
      padding: 50px 20px;
    }

    section h2 {
      color: #333;
      margin-bottom: 20px;
    }

    footer {
      background-color: #333;
      color: white;
      padding: 20px;
      margin-top: 30px;
    }
  </style>

</head>

<body>

  <header>
    <img src="profile.jpg" alt="photo barzani">
    <h1>Matin Barzani</h1>
    <p>Programmer and technology enthusiast</p>

    <div class="social">
      <a href="https://www.instagram.com/matin.mzurii">Instagram</a>
      <a href="https://www.snapchat.com/add/matin.barzany">Snapchat</a>
      <a href="https://www.youtube.com/@matin.salimi">YouTube</a>
    </div>
  </header>

  <section>
    <h2>About me</h2>
    <p>Hello! I am Matin, a programmer interested in technology and web design. This is my personal site where I share my information.</p>
  </section>

  <footer>
    &copy; Barzani — My number: 0964 750 725 8222 (Telegram, WhatsApp, Viber)
  </footer>

</body>
</html>
